from django.urls import path
from . import views
from django.contrib.auth.views import LogoutView

urlpatterns = [
    path("" , views.inicio, name="home"),
    path("pacientes" , views.pacientes, name ="pacientes"),
    path("profesionales", views.profesionales , name="profesionales"),
    path("sucursales", views.sucursales , name ="sucursales"),
    path("staff", views.staff, name='staff'),
    path("alta_paciente", views.paciente_formulario, name="alta_paciente"),
    path("buscar_paciente", views.buscar_paciente),
    path("buscar", views.buscar),
    path("eliminar_paciente/<int:id>", views.eliminar_paciente, name="eliminar_paciente"),
    path("editar_paciente/<int:id>", views.editar, name="editar_paciente"),
    path("editar_paciente", views.editar, name="editar_paciente"),
    path("login", views.login_request, name="Login"),
    path("register", views.register, name="Register"),
    path("logout", LogoutView.as_view(template_name="logout.html"), name="Logout"),
    path("editarPerfil", views.editarPerfil, name="EditarPerfil"),
    path("about", views.about, name="about")

]
