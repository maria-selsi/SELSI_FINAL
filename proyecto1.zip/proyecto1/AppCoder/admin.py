from django.contrib import admin
from .models import *

admin.site.register(Paciente)
admin.site.register(Avatar)



# Register your models here.
