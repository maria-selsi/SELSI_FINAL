from django.shortcuts import render
from AppCoder.models import Paciente, Avatar, Staff
from django.template import loader
from django.http import HttpResponse
from AppCoder.forms import Paciente_form , UserEditForm
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required

# Create your views here.

def inicio(request):
    return render(request, "padre.html")

@login_required
def pacientes(request):
    pacientes = Paciente.objects.all()
    return render (request, "pacientes.html", {"pacientes":pacientes})

def alta_paciente(request, nombre_pac, tipo_pac, raza_pac, edad_pac, dueno_pac, contacto_pac):
    paciente = Paciente(nombre_pac=nombre_pac, tipo_pac=tipo_pac, raza_pac=raza_pac, edad_pac=edad_pac, dueno_pac=dueno_pac, contacto_pac=contacto_pac)
    paciente.save()
    texto = f"Se guardó en la BD el paciente: {paciente.nombre_pac}, Raza {paciente.raza_pac}"
    return HttpResponse(texto)

@login_required
def staff(request):
    staff = Staff.objects.all()
    return render (request, "staff.html", {"staff":staff})

def profesionales(request):
    avatares = Avatar.objects.filter(user=request.user.id)
    return render(request, "profesionales.html")

def sucursales(request):
    return render( request, "sucursales.html")

def paciente_formulario(request):
    if request.method == "POST":

        mi_formulario = Paciente_form(request.POST)

        if mi_formulario.is_valid():
            datos = mi_formulario.cleaned_data
            paciente = Paciente(nombre_pac=datos['nombre_pac'],tipo_pac=datos['tipo_pac'], raza_pac=datos['raza_pac'], edad_pac=datos['edad_pac'], dueno_pac=datos['dueno_pac'], contacto_pac=datos['contacto_pac'])
            paciente.save()
            return render( request, "formulario.html")
    return render( request, "formulario.html")

def buscar_paciente(request):
    return render(request, "buscar_paciente.html")

def buscar(request):
    if request.GET['nombre_pac']:
        nombre_pac = request.GET['nombre_pac']
        pacientes = Paciente.objects.filter(nombre_pac__icontains = nombre_pac)
        return render( request, "resultado_busqueda.html", {"pacientes": pacientes})
    else:
        return HttpResponse("Campo vacío")

def eliminar_paciente(request, id):
    paciente = Paciente.objects.get(id=id)
    paciente.delete()

    pacientes = Paciente.objects.all()

    return render(request, "pacientes.html", {"pacientes": pacientes})

def editar(request, id):
    paciente = Paciente.objects.get(id=id)
    if request.method == "POST":
        mi_formulario = Paciente_form(request.POST)
        if mi_formulario.is_valid():
            datos = mi_formulario.cleaned_data
            paciente.nombre_pac = datos['nombre_pac']
            paciente.tipo_pac = datos['tipo_pac']
            paciente.raza_pac = datos['raza_pac']
            paciente.edad_pac = datos['edad_pac']
            paciente.dueno_pac = datos['dueno_pac']
            paciente.contacto_pac = datos['contacto_pac']
            paciente.save()

            pacientes = Paciente.objects.all()
            return render(request, "pacientes.html", {"pacientes":pacientes})
    else:
        mi_formulario = Paciente_form(initial={"nombre_pac":paciente.nombre_pac, "tipo_pac":paciente.tipo_pac, "raza_pac":paciente.raza_pac, "edad_pac":paciente.edad_pac, "dueno_pac":paciente.dueno_pac, "contacto_pac":paciente.contacto_pac})

    return render(request, "editar_paciente.html", {"mi_formulario":mi_formulario, "paciente":paciente})

def login_request(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data= request.POST)

        if form.is_valid():
            usuario = form.cleaned_data.get("username")
            contra = form.cleaned_data.get("password")

            user = authenticate(username=usuario, password=contra)

            if user is not None:
                login(request, user)

                avatares = Avatar.objects.filter(user=request.user.id)
                return render(request, "inicio.html", {"url":avatares[0].imagen.url})
            else:
                return HttpResponse(f"Usuario incorrecto")
        else:
            return HttpResponse(f"FORM INCORRECTO {form}")
    
    form = AuthenticationForm()
    return render(request, "login.html", {"form": form})

def register(request):
    if request.method =="POST":
        form = UserCreationForm(request.POST)

        if form.is_valid():
            form.save()
            return HttpResponse("Usuario creado")
    
    else:
        form = UserCreationForm()
    return render(request, "registro.html", {"form":form})

def editarPerfil(request):
    usuario = request.user

    if request.method == "POST":
        miFormulario = UserEditForm(request.POST)

        if miFormulario.is_valid():
            informacion = miFormulario.cleaned_data
            usuario.email= informacion['email']
            password = informacion['password1']
            usuario.set_password(password)
            usuario.save()

            return render(request, "inicio.html")
    else:
        miFormulario = UserEditForm(initial={'email':usuario.email})

    return render(request, "editar_perfil.html", {'miFormulario':miFormulario, "usuario":usuario})

def about(request):
    return render( request, "about.html")
