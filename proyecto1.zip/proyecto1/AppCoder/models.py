from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class Paciente(models.Model):
    nombre_pac = models.CharField(max_length=30)
    tipo_pac = models.CharField(max_length=20)
    raza_pac = models.CharField(max_length=30)
    edad_pac = models.IntegerField()
    dueno_pac = models.CharField(max_length=30)
    contacto_pac = models.IntegerField()

    def __str__(self):
        return f"Nombre: {self.nombre_pac} - Tipo {self.tipo_pac} - Edad {self.edad_pac}"

class Staff(models.Model):
    nombre_vet = models.CharField(max_length=25)
    apellido_vet = models.CharField(max_length=25)
    direccion_vet = models.CharField(max_length=40)
    telefono_vet = models.IntegerField()
    sucursal_vet = models.CharField(max_length=25)

    def __str__(self):
        return f"Nombre: {self.nombre_vet}, Apellido: {self.apellido_vet}, Teléfono: {self.telefono_vet}"

class Avatar(models.Model):
    user = models.ForeignKey(User , on_delete=models.CASCADE)
    imagen = models.ImageField(upload_to='avatares', null=True, blank=True)