from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.db import models
from django.contrib.auth.models import User

class Paciente_form(forms.Form):
    nombre_pac = models.CharField(max_length=30)
    tipo_pac = models.CharField(max_length=20)
    raza_pac = models.CharField(max_length=30)
    edad_pac = models.IntegerField()
    dueno_pac = models.CharField(max_length=30)
    contacto_pac = models.IntegerField()

class UserEditForm(UserCreationForm):
    email = forms.EmailField(label="Modificar")
    password1 = forms.CharField(label="Contraseña", widget=forms.PasswordInput)
    password2 = forms.CharField(label="Repetir la contraseña", widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ['email', 'password1', 'password2']
        help_text = {k:"" for k in fields}
