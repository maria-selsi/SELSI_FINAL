from django.http import HttpResponse
from django.template import Template, Context, loader

def test_template(request):
    datos = {"nombre":"Pepe", "notas":[1,2,3,4,5,10]}
    plantilla = loader.get_template("template.html")
    documento = plantilla.render(datos)

    return HttpResponse(documento)


"""
def test_template(request):

    mi_html = open("C:/Pyhton/Proyecto2/proyecto1/proyecto1/plantillas/template.html")

    plantilla = Template(mi_html.read())

    mi_html.close()

    mi_contexto = Context({"nombre":"Pepe", "notas":[1,2,3,4,5,10]})
    documento = plantilla.render(mi_contexto)

    return HttpResponse(documento)
    """